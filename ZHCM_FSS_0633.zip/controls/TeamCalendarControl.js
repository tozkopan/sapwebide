sap.ui.define([
	"hcm/fab/lib/common/controls/TeamCalendarControl",
	"sap/ui/model/odata/v2/ODataModel",
	"./CalendarLegend",
	"./CalendarLegendItem"
], function(BaseControl, ODataModel, CalendarLegend, CalendarLegendItem) {
	"use strict";

	var TeamCalendarControl = BaseControl.extend("nornickel.mss.teamCalendar.controls.TeamCalendarControl", {
		metadata: {
			aggregations: {
				_zEventDetailMultiPopover: {
					type: "sap.m.ResponsivePopover",
					multiple: false,
					visibility: "hidden"
				},
				_zLegendDialog: {
					type: "sap.m.Dialog",
					multiple: false,
					visibility: "hidden"
				}
			}
		},
		renderer: {},
		
		init: function() {
			if (BaseControl.prototype.init) {
				BaseControl.prototype.init.apply(this, arguments);
			}
			
			this._oDataManager._oModel = new ODataModel("/sap/opu/odata/sap/ZHCM_FSS_0633_TEAM_CALEND_SRV/", {
				disableHeadRequestForToken: true,
				useBatch: true
			});
			
			this.attachDataChanged(this.zOnDataChanged.bind(this));
			
			var oCalendar = this.getAggregation("_calendar");
			oCalendar.setBuiltInViews([
				sap.m.PlanningCalendarBuiltInView.OneMonth,
				sap.m.PlanningCalendarBuiltInView.Week,
				sap.m.PlanningCalendarBuiltInView.Month
			]);
			oCalendar.addView(new sap.m.PlanningCalendarView({
				id: this.createId("twoWeekView"),
				key: "Two Week",
				intervalType: sap.ui.unified.CalendarIntervalType.Day,
				description: "2 недели",
				intervalsS: 14,
				intervalsM: 14,
				intervalsL: 14
			}));
			//oPlanningCalendarProperties.viewKey = "Month";
			
			//request data if view type is changed
			oCalendar.attachViewChange(this.onCalendarStartDateChange.bind(this));
			
			
			//redefine method of calendar monkey style - rename view names
			var fnGetViews = oCalendar._getViews;
			oCalendar._getViews = function() {
				console.log("_getViews redefined");
				return fnGetViews.apply(this, arguments).map(function(x) {
					switch (x.getKey()) {
						case "One Month": x.setDescription("Месяц"); break;
						case "Week":      x.setDescription("Неделя"); break;
						case "Month":     x.setDescription("Год"); break;
						case "Two Week":  x.setDescription("2 недели"); break;
					}
					return x;
				});
			};
			
			//popover for multi events
			var oMultiPopoverList = new sap.m.List({
				items: {
					path: "CalendarModel>/zEventDetailMultiPopover",
					templateShareable: false,
					template: new sap.m.DisplayListItem({
						label: "{CalendarModel>Title}",
						type: "Active",
						press: function(evt) {
							var oSrc = evt.getSource(),
								oCtx = oSrc.getBindingContext("CalendarModel"),
								oParent = this.getAggregation("_zEventDetailMultiPopover")._zParent;
							this.onEventClick({
								getParameter: function() {
									return $.extend(oSrc, {
										getBindingContext: function() { return oCtx; },
										getParent: function() { return oParent; },
										setSelected: function() { }
									});
								}
							});
						}.bind(this)
					})
				}
			});
			this.setAggregation("_zEventDetailMultiPopover", new sap.m.ResponsivePopover({
				id: this.createId("zEventDetailMultiPopover"),
				placement: sap.m.PlacementType.Auto,
				modal: false,
				showHeader: false,
				content: oMultiPopoverList
			}));
			
			var oLegend = new CalendarLegend({
				id: this.createId("zLegendDialogLegend"),
				items: {
					path: "CalendarModel>/legendItems",
					templateShareable: false,
					template: new CalendarLegendItem({
						type: "{CalendarModel>EventType}",
						text: "{CalendarModel>Description}",
						color: "{CalendarModel>Color}",
						zCheckbox: [new sap.m.CheckBox({
							selected: "{CalendarModel>zSelected}",
							select: this.zOnCalendarLegendChange.bind(this)
						})],
						zIcon: [new sap.ui.core.Icon({
							src: "{CalendarModel>Icon}"
						})]
					})
				}
			});

			this.setAggregation("_zLegendDialog", new sap.m.Dialog({
				id: this.createId("zLegendDialog"),
				title: "{libI18N>legendDialogTitle}",
				content: oLegend,
				endButton: new sap.m.Button({
					id: this.createId("zLegendDialogCancelButton"),
					text: "{libI18N>legendCancelButtonText}",
					tooltip: "{libI18N>legendCancelButtonTooltip}",
					press: function() {
						this.getAggregation("_zLegendDialog").close();
					}.bind(this)
				})
			}));
			
			this._oDataManager._oModel.setUseBatch(false); //temp
			
		}

	});
	
	TeamCalendarControl.prototype.zTimeRangeChange = function(evt) {
		var sKey = evt.getParameter("item").getKey(),
			oCalendar = this.getAggregation("_calendar");
		oCalendar.setBuiltInViews([
			sap.m.PlanningCalendarBuiltInView[sKey]
		]);
	};
	
	TeamCalendarControl.prototype._getCurrentViewDimension = function() {
		var key = this.getAggregation("_calendar").getViewKey();
		switch (key) {
			case "Week":      return 7;
			case "Two Week":  return 14;
			case "One Month": return 31;
			case "Month":     return 366;
			default:          return 31;
		}
	};
	
	TeamCalendarControl.prototype.onEventClick = function(oControlEvent) {
		if(oControlEvent.getParameter("appointment")) {
			BaseControl.prototype.onEventClick.apply(this, arguments);
			// setTimeout(BaseControl.prototype.onEventClick.bind(this, oControlEvent));
			return;
		}
				
		var oModel = this.getModel("CalendarModel"),
			aAppointments = oControlEvent.getParameter("appointments"),
			oDomRef = sap.ui.getCore().byId(oControlEvent.getParameter("domRefId")),
			oPopover = this.getAggregation("_zEventDetailMultiPopover");
			
		oModel.setProperty("/zEventDetailMultiPopover", aAppointments.map(function(x) {
			return oModel.getProperty(x.getBindingContext("CalendarModel").getPath());
		}));
		
		oPopover._zParent = aAppointments[0].getParent();
		
		oPopover.openBy(oDomRef);
		
	};
	
	TeamCalendarControl.prototype.onEventDetailClosePressed = function() {
		if (BaseControl.prototype.onEventDetailClosePressed) {
			BaseControl.prototype.onEventDetailClosePressed.apply(this, arguments);
		}
		if(this._zEventDetailMultiPopover) {
			this._zEventDetailMultiPopover.close();
		}
	};
	
	TeamCalendarControl.prototype.onLegendButtonPress = function() {
		// this.getAggregation("_legendDialog").open();
		this.getAggregation("_zLegendDialog").open();
	};
	
	TeamCalendarControl.prototype.zOnCalendarLegendChange = function(evt) {
		console.log("zOnCalendarLegendChange");
		this._zApplyEventTypeVisibility();
	};
	
	TeamCalendarControl.prototype._updateLegendItems = function(evt) {
		BaseControl.prototype._updateLegendItems.apply(this, arguments);
		
		var aItems = this._oLocalModel.getProperty("/legendItems").map(function(x) {
			x.zSelected = x.zSelected !== false;
			return x;
		});
		this._oLocalModel.setProperty("/legendItems", aItems);
		
		this._zApplyEventTypeVisibility();
	};
	
	TeamCalendarControl.prototype._zApplyEventTypeVisibility = function(evt) {
		console.log("_zCalendarLegendUpdate");
		var aItems = this._oLocalModel.getProperty("/legendItems"),
			aEmployeeList = this._oLocalModel.getProperty("/employeeList");
		if(!aEmployeeList || !aItems) { return; }
		
		var oVisibleEventTypes = aItems.reduce(function(a, x) {
			if(x.zSelected !== false) {
				a[x.EventType] = true;
			}
			return a;
		}, {});
		
		aEmployeeList.forEach(function(oEmployee) {
			oEmployee.ToTeamCalendarEvent = oEmployee.zToTeamCalendarEvent.filter(function(oEvent) {
				return oVisibleEventTypes[oEvent.EventType];
			});
		});
		
		this._oLocalModel.setProperty("/employeeList", aEmployeeList);
			
		//this.getAggregation("_calendar").getBinding("rows").filter(new Filter(aFilter, true), "Application");
		
	};
	
	TeamCalendarControl.prototype.zOnDataChanged = function(evt) {
		console.log("zOnDataChanged");
		//backup events
		this._oLocalModel.getProperty("/employeeList").forEach(function(oEmployee) {
			oEmployee.zToTeamCalendarEvent = oEmployee.ToTeamCalendarEvent.slice();
		});
		
		// this._oLocalModel.setProperty("/employeeList", );
		this._zApplyEventTypeVisibility();
		
	};
	
	return TeamCalendarControl;
});