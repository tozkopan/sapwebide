sap.ui.define([
	"sap/ui/unified/CalendarLegendItem"
], function(BaseControl) {
	"use strict";

	// var BaseRenderer = BaseControl.prototype.getRenderer();
	var oControl = BaseControl.extend("nornickel.mss.teamCalendar.controls.CalendarLegendItem", {
		metadata: {
			aggregations: {
				zCheckbox: {
					type: "sap.m.CheckBox",
					multiple: false
				},
				zIcon: {
					type: "sap.ui.core.Icon",
					multiple: false
				}
			}
		}
		
	});
	
	return oControl;
});