sap.ui.define([
	"sap/ui/unified/CalendarLegend"
], function(BaseControl) {
	"use strict";

	var BaseRenderer = BaseControl.prototype.getRenderer();
	var TeamCalendarControl = BaseControl.extend("nornickel.mss.teamCalendar.controls.CalendarLegend", {
		metadata: {
			aggregations: {
				zCheckbox: {
					type: "sap.m.CheckBox",
					multiple: true,
					visibility: "hidden"
				}
			}
		},
		renderer: {
			renderLegendItem: function(oRm, sClass, oItem, aColorClasses) {
				oRm.write("<div");
				oRm.addStyle("display", "flex");
				oRm.addStyle("align-items", "center");
				oRm.addStyle("margin", "8px 0");
				oRm.writeStyles();
				oRm.writeClasses();
				oRm.write(">");
				
				if(typeof oItem.getZCheckbox === "function") {
					oRm.renderControl(oItem.getZCheckbox());
				}else{ //empty substitution
					oRm.write("<div class='sapMCb'/>");
				}
				
				oRm.write("<div");
				oRm.addStyle("width", "32px");
				oRm.addStyle("text-align", "center");
				oRm.writeStyles();
				oRm.write(">");
				if(typeof oItem.getZIcon === "function") {
					var zIcon = oItem.getZIcon();
					zIcon.setColor("black");
					zIcon.setSize("16px");
					oRm.renderControl(zIcon);
				}else{ //empty substitution
					// oRm.write("<div class='sapMCb'/>");
				}
				oRm.write("</div>");
				
				BaseRenderer.renderLegendItem.apply(this, arguments);
				
				oRm.write("</div>");
			}
		},
		
		init: function() {
			if (BaseControl.prototype.init) {
				BaseControl.prototype.init.apply(this, arguments);
			}
			this.addStyleClass("zLegendDialogLegend");
		}

	});
	
	return TeamCalendarControl;
});